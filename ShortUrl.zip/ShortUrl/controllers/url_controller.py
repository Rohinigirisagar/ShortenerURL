import shortuuid
from flask import redirect 

url_database = {}

def shorten_url(long_url):
    short_code = shortuuid.uuid()[:6]  # Generating a short code using shortuuid
    url_database[short_code] = long_url
    return f'http://localhost:5000/{short_code}'

def redirect_url(short_code):
    long_url = url_database.get(short_code)
    if long_url:
        return redirect(long_url)
    else:
        return 'URL not found',404